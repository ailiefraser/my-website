/***********************************************************
     Starter code for Assignment 3

     This code was originally written by Jack Wang for
		    CSC418, SPRING 2005

		implements scene_object.h
 
    This code has been extended and modified by Ailie Fraser.

***********************************************************/

#include <cmath>
#include <iostream>
#include "scene_object.h"

// Tolerance: to handle inexact floating point values
const double TOL = 0.0000001;

bool UnitSquare::intersect( Ray3D& ray, const Matrix4x4& worldToModel,
		const Matrix4x4& modelToWorld ) {
	// Implement intersection code for UnitSquare, which is
	// defined on the xy-plane, with vertices (0.5, 0.5, 0), 
	// (-0.5, 0.5, 0), (-0.5, -0.5, 0), (0.5, -0.5, 0), and normal
	// (0, 0, 1).
	//
	// Your goal here is to fill ray.intersection with correct values
	// should an intersection occur.  This includes intersection.point, 
	// intersection.normal, intersection.none, intersection.t_value.   
	//
	// HINT: Remember to first transform the ray into object space  
	// to simplify the intersection test.

	// Transform the ray to object (model) space
	Ray3D modelRay;
	modelRay.origin = worldToModel * ray.origin;
	modelRay.dir = worldToModel * ray.dir;

	// The path of the ray as a function of time = modelRay.origin + time * modelRay.dir
	// Since we are in model space, the point where the ray intersects this square will be
	// the point where its z-coordinate is 0. So we solve the equation:
	// modelRay.origin[2] + time * modelRay.dir[2] = 0
	double time = - modelRay.origin[2]/modelRay.dir[2];

	// Save the coordinates of the point at this time.
	Point3D intersectionPoint = modelRay.origin + time * modelRay.dir;
	// Check if the point is inside the unit square.
	if (time > 0 && fabs(intersectionPoint[0]) <= 0.5 - TOL && fabs(intersectionPoint[1]) <= 0.5 - TOL) {
		// Only save this intersection point if the ray doesn't already have one, or it does but behind this one.
		if (ray.intersection.none || ray.intersection.t_value > time) {
			ray.intersection.none = false;
			ray.intersection.t_value = time;
			ray.intersection.point = modelToWorld * intersectionPoint;
			ray.intersection.normal = worldToModel.transpose() * Vector3D (0.0, 0.0, 1.0);
			// Used for generating the scene signature:
			//ray.col = Colour (0, 1, 0);
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

bool UnitSphere::intersect( Ray3D& ray, const Matrix4x4& worldToModel,
		const Matrix4x4& modelToWorld ) {
	// Implement intersection code for UnitSphere, which is centred 
	// on the origin.  
	//
	// Your goal here is to fill ray.intersection with correct values
	// should an intersection occur.  This includes intersection.point, 
	// intersection.normal, intersection.none, intersection.t_value.   
	//
	// HINT: Remember to first transform the ray into object space  
	// to simplify the intersection test.
	
	// Transform the ray to object (model) space
	Ray3D modelRay;
	modelRay.origin = worldToModel * ray.origin;
	modelRay.dir = worldToModel * ray.dir;

	// Substitute the parametric definition of the ray's path into the equation for the sphere (x^2 + y^2 + z^2 = 1):
	// (ori[0] + time * dir[0])^2 + (ori[1] + time * dir[1])^2 + (ori[2] + time * dir[2])^2 = 1
	// Solve for time using the quadratic equation (at^2 + bt + c = 0):
	// time^2 (dir[0]^2 + dir[1]^2 + dir[2]^2) + 2*time (ori[0] dir[0] + ori[1] dir[1] + ori[2] dir[2])
	// + ori[0]^2 + ori[1]^2 + ori[2]^2 - 1 = 0
	double a = modelRay.dir[0] * modelRay.dir[0] + modelRay.dir[1] * modelRay.dir[1] + modelRay.dir[2] * modelRay.dir[2];
	double b = 2.0 * (modelRay.origin[0] * modelRay.dir[0] + modelRay.origin[1] * modelRay.dir[1]
	           + modelRay.origin[2] * modelRay.dir[2]);
	double c = modelRay.origin[0] * modelRay.origin[0] + modelRay.origin[1] * modelRay.origin[1]
               + modelRay.origin[2] * modelRay.origin[2] - 1.0;

	// The discriminant
	double disc = b*b - 4*a*c;

	if (disc < 0) { // The ray does not intersect the sphere.
		return false;
	}
	// Otherwise, there are either one or two intersection points.
	double time;
	if (fabs(disc) < TOL) { // Discriminant very close to 0 => 1 intersection point
		time = -b/(2 * a);
		if (time < 0) { // The intersection point is behind the view plane, so we don't see it.
			return false;
		}
	} else { // disc > 0 => There are 2 intersection points, so we want the closer one (= smaller time value)
		double t1 = (-b - sqrt(disc))/(a+a);
		double t2 = (-b + sqrt(disc))/(a+a);
		if (t1 > 0) {
			time = t1;
		} else if (t2 > 0) {
			time = t2;
		} else {
			return false;
		}
	}
	// If we get here, we have found a time value for a valid intersection point. Only save it if the ray
	// doesn't already have an intersection point, or it does but is behind this one.
	if ((ray.intersection.none || ray.intersection.t_value > time)) {
		Point3D intersectionPoint = modelRay.origin + time * modelRay.dir;
		ray.intersection.none = false;
		ray.intersection.t_value = time;
		ray.intersection.point = modelToWorld * intersectionPoint;
		ray.intersection.normal = transNorm (worldToModel,
				Vector3D (intersectionPoint[0], intersectionPoint[1], intersectionPoint[2]));
		// Used for generating the scene signature:
		//ray.col = Colour (1, 0, 0);
		return true;
	} else {
		return false;
	}
}

