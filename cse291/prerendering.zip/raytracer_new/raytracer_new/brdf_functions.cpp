//
//  brdf_functions.cpp
//  raytracer_new
//
//  Created by Ailie Fraser on 2015-02-04.
//  Copyright (c) 2015 Ailie Fraser. All rights reserved.
//

#include "brdf_functions.h"

/** Return the value for the phong BRDF given its material parameters 
  * s = direction from point on surface to light source, in local coords
  * n = normal to surface, in local coords
  * c = direction from point on surface to camera, in local coords
 **/
Colour phong_specular(Vector3D s, Vector3D n, Vector3D c, Colour specular, double specular_exp) {
    
    s.normalize();
    n.normalize();
    c.normalize();
    
    // Mirror reflection direction
    Vector3D m = -s + (2 * s.dot(n) * n);
    m.normalize();
    
    //Colour result = ambient + (std::max(0.0, s.dot(n)) * diffuse) + (pow(std::max(0.0, c.dot(m)), specular_exp) * specular);
    //Colour result = diffuse + ((pow(std::max(0.0, c.dot(m)), specular_exp))/(s.dot(n)))*specular;
    
    // SPECULAR ONLY - and normalized
    Colour result = ((specular_exp + 1)/(2 * M_PI))*((pow(std::max(0.0, c.dot(m)), specular_exp))/(s.dot(n)))*specular;
    
    //printf("brdf: %f %f %f\n", result[0], result[1], result[2]);
    return result;
}

Colour phong_specular_unnormalized(Vector3D s, Vector3D n, Vector3D c, Colour specular, double specular_exp) {
    
    s.normalize();
    n.normalize();
    c.normalize();
    
    // Mirror reflection direction
    Vector3D m = -s + (2 * s.dot(n) * n);
    m.normalize();
    
    //Colour result = ambient + (std::max(0.0, s.dot(n)) * diffuse) + (pow(std::max(0.0, c.dot(m)), specular_exp) * specular);
    //Colour result = diffuse + ((pow(std::max(0.0, c.dot(m)), specular_exp))/(s.dot(n)))*specular;
    
    // SPECULAR ONLY - and normalized
    Colour result = ((pow(std::max(0.0, c.dot(m)), specular_exp))/(s.dot(n)))*specular;
    
    //printf("brdf: %f %f %f\n", result[0], result[1], result[2]);
    return result;
}

Colour torrance_specular(Vector3D s, Vector3D n, Vector3D c, Colour specular, double sigma) {
    
    s.normalize();
    n.normalize();
    c.normalize();
    
    Vector3D h = s + c;
    h.normalize();
    //printf("h: %f, %f, %f\n", h[0], h[1], h[2]);
    
    double theta_h = acos(n.dot(h));
    //printf("theta h: %f\n", theta_h);
    
    double S = (1 / (M_PI * sigma * sigma)) * (std::exp(-(std::pow(theta_h / sigma, 2))));
    
    Colour result = (S / (4 * n.dot(s) * n.dot(c))) * specular;
    
    return result;
}
