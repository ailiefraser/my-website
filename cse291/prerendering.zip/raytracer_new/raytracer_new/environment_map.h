//
//  environment_map.h
//  raytracer_new
//
//  Created by Ailie Fraser on 2015-01-23.
//  Copyright (c) 2015 Ailie Fraser. All rights reserved.
//

#ifndef __raytracer_new__environment_map__
#define __raytracer_new__environment_map__

#include <stdio.h>
#include <assert.h>
#include "util.h"

class EnvironmentMap {
public:
    EnvironmentMap( char * filename, Matrix4x4& worldToObject, filetype fileType, double spec_exp, Colour spec, Colour dif);
    void shade_mirror( Ray3D& ray );
    void shade( Ray3D& ray, BRDFmodel brdf_model);
    unsigned char * getRBuffer() { return _rbuffer; }
    unsigned char * getGBuffer() { return _gbuffer; }
    unsigned char * getBBuffer() { return _bbuffer; }
    int getWidth() { return _N; }
    int getHeight() { return _M; }
    
    double specular_exp;
    Colour specular;
    Colour diffuse;
    
private:
    
    int count;
    const static int size = 300; // height and width of HDR env maps
    
    void initialize_values();
    float readfloat(FILE * fp);
    void writeimage(char *filename, float scalefac, float image[3][size][size]);
    void get_u_v(Ray3D& ray, int *u, int*v);
    
    // type of file for the env map (HDR = .out (floats), BMP = .bmp)
    filetype _fileType;
    
    // dimensions of env map
    int _M; // height
    int _N; // width
    
    // RGB buffers holding the intensity values at every pixel (u, v) on the env map
    unsigned char* _rbuffer;
    unsigned char* _gbuffer;
    unsigned char* _bbuffer;
    
    // RGB values for HDR environment map
    float _floatfile[3][size][size];
    
    /* Prefiltering stuff */

    // 2D array holding values of L_i for every u_i, v_i
    Colour *_L_i;
    
    // 2D array holding values of theta_i for every u_i, v_i on the env map
    double *_theta_i;
    // same for phi_i
    double *_phi_i;
    // same for the vector in world coordinates d_i = (x_i, y_i, z_i)
    Vector3D *_d_i;
    // same for s = d_i in sphere's coordinate frame
    Vector3D *_s;
    
    // Solid angle measures
    double _dtheta_i; // same for every point
    double _dphi_i; // same for every point
    // 2D array holding values of dw_i for every u_i, v_i
    // dw_i = sin(theta_i) * dtheta_i * dphi_i
    double *_dw_i;
    
    Matrix4x4 _worldToObject; // world to sphere transformation matrix
};

#endif /* defined(__raytracer_new__environment_map__) */
