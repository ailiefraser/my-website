//
//  environment_map.cpp
//  raytracer_new
//
//  Created by Ailie Fraser on 2015-01-23.
//  Copyright (c) 2015 Ailie Fraser. All rights reserved.
//

#include "environment_map.h"
#include "bmp_io.h"
#include "ppmb_io.hpp"
#include "brdf_functions.h"
#include <cmath>

EnvironmentMap::EnvironmentMap(char * filename, Matrix4x4& worldToObject, filetype fileType, double spec_exp, Colour spec, Colour dif) {
    
    _worldToObject = worldToObject;
    _fileType = fileType;
    
    specular_exp = spec_exp;
    specular = spec;
    diffuse = dif;
    
    //printf("%f %f %f %f\n%f %f %f %f\n%f %f %f %f\n%f %f %f %f\n", _worldToObject[0][0], _worldToObject[0][1], _worldToObject[0][2], _worldToObject[0][3], _worldToObject[1][0], _worldToObject[1][1], _worldToObject[1][2], _worldToObject[1][3], _worldToObject[2][0], _worldToObject[2][1], _worldToObject[2][2], _worldToObject[2][3], _worldToObject[3][0], _worldToObject[3][1], _worldToObject[3][2], _worldToObject[3][3]);
    
    count = 0;
    
    switch (_fileType) {
    
        case BMP: {
            unsigned long int width;
            long int height;
            _rbuffer = NULL;
            _gbuffer = NULL;
            _bbuffer = NULL;
            // note the order of the buffers: BRG. For some reason this is the actual order they get read as
            bool result = bmp_read(filename, &width, &height, &_bbuffer, &_rbuffer, &_gbuffer);
             if (!result) {
                printf("Successfully read bmp file\n");
             } else {
                printf("Error reading bmp file\n");
             }
            
            _M = (int)height;
            _N = (int)width;
            
            int numbytes = _N * _M * sizeof(unsigned char);
            
            //printf("numbytes: %d\n", numbytes);
            for (int i=0; i < numbytes; i++) {
                //printf("%d, %d, %d \n", (int)_rbuffer[i], (int)_gbuffer[i], (int)_bbuffer[i]);
            }
            
            bmp_write( "new_test.bmp", width, height, _rbuffer, _gbuffer, _bbuffer );
            break;
        }
        case PPM: {
            int width;
            int height;
            int rgb_max;
            _rbuffer = NULL;
            _gbuffer = NULL;
            _bbuffer = NULL;
            bool result = ppmb_read(filename, width, height, rgb_max, &_rbuffer, &_gbuffer, &_bbuffer);
            if (!result) {
                printf("Successfully read ppm file\n");
            } else {
                printf("Error reading ppm file\n");
            }
            printf("height: %d, width : %d\n", height, width);
            _M = height;
            _N = width;
            
            ppmb_write("ppm_test.ppm", width, height, _rbuffer, _gbuffer, _bbuffer);
            break;
        }
        case HDR: {
    
            // For HDR env map i.e. myfloat.out
            FILE *fp;
            fp = fopen(filename, "rb");
            int i, j, k;
            float max = 0.0;
            for (i = 0; i < size ; i++) {
                for (j = 0 ; j < size ; j++) {
                    for (k = 0 ; k < 3 ; k++) {
                        _floatfile[k][i][j] = readfloat(fp);
                        if (_floatfile[k][i][j] > max) {
                            max = _floatfile[k][i][j];
                        }
                    }
                }
            }
            printf("max: %f\n", max);
            fclose(fp);
            
            _M = size;
            _N = size;
            
            writeimage("env_map_copy_out.ppm", 10000, _floatfile);
            break;
        }
    }
    
    
    // Do some precomputing of the environment map
    initialize_values();

}

/* From Ravi's spherical harmonics code shlighting.c */
float EnvironmentMap::readfloat(FILE * fp) {
    float val ;
    unsigned char *c = (unsigned char *) (&val) ;
    fscanf(fp,"%c%c%c%c",&(c[3]),&(c[2]),&(c[1]),&(c[0])) ;
    return val ;
}

/* From Ravi's spherical harmonics code shlighting.c */
void EnvironmentMap::writeimage(char *filename, float scalefac, float image[3][size][size]) {
    FILE *fp ;
    int i,j,k ;
    assert(fp = fopen(filename,"wb")) ;
    fprintf(fp,"P6\n%d %d\n%d\n",size,size,255) ;
    for (i = 0 ; i < size ; i++) {
        for (j = 0 ; j < size ; j++)
            for (k = 0 ; k < 3 ; k++) {
                float v = scalefac*image[k][i][j] ;
                //v = remap(v) ;
                unsigned char c ;
                if (v < 0) c = (unsigned char) 0 ;
                else if (v > 255) c = (unsigned char) 255 ;
                else c = (unsigned char) v ;
                fprintf(fp,"%c",c) ;
            }
        //    fprintf(stderr,"Done line %d\n",i) ;
    }
    fclose(fp) ;
}


void EnvironmentMap::shade_mirror(Ray3D& ray) {
    
    // This makes a perfect mirror ball, by getting the reflection direction for each point (the ray reflected off the
    // surface when a ray is cast to the surface from the camera) and finds the point on the environment map corresponding
    // to that direction.
    // To simply map the env map onto the sphere instead, replace m with ray.intersection.normal when calculating theta and phi.
    
    // normal to sphere = ray.intersection.normal ([0], [1], [2])
    ray.intersection.normal.normalize();
    
    int u_int, v_int;
    get_u_v(ray, &u_int, &v_int);
    
    int index = v_int * _N + u_int;

    
    Colour col = _L_i[index];
    ray.col = col;
    ray.col.clamp();
}

void EnvironmentMap::shade(Ray3D& ray, BRDFmodel brdf_model) {
    
    count++;
    //printf("sphere point number %d\n", count);
    
    // normal to sphere = ray.intersection.normal ([0], [1], [2])
    ray.intersection.normal.normalize();
    ray.dir.normalize();
    
    //int u_int, v_int;
    //get_u_v(ray, &u_int, &v_int);
    
    //int index = v_int * _N + u_int;
    
    // n_s = ray.intersection.normal in sphere's coordinates
    Vector3D n_s = _worldToObject * ray.intersection.normal;
    
    //c = (x_c, y_c, z_c) = direction to camera from point on sphere
    Vector3D c = -ray.dir;
    
    //c_s = c in sphere's coordinates
    Vector3D c_s = _worldToObject * c;
    
    // Calculate the intensity for this point using the reflection equation.

    Colour sum(0.0, 0.0, 0.0);
    
    // Iterate over all possible incoming light directions = all points on environment map
    // If a point on the map is not visible from this point on the sphere, its BRDF value will
    // evaluate to 0 because the dot product s.n will be negative, so this point won't get counted.
    int u_i, v_i, index_i;
    double angle;
    for (u_i = 0; u_i < _N; u_i++) {
        for (v_i = 0; v_i < _M; v_i++) {
            //printf("(u, v) = (%d, %d)\n", u_i, v_i);
            index_i = v_i * _N + u_i;
            
            angle = std::max(0.0, _d_i[index_i].dot(ray.intersection.normal));
            //printf("angle: %f\n", angle);

            Colour brdf;
            if (angle > 0) {
                switch (brdf_model) {
                    case PHONG: {
                        brdf = phong_specular(_s[index_i], n_s, c_s, specular, specular_exp);
                        break;
                    }
                    case TORRANCE: {
                        brdf = torrance_specular(_s[index_i], n_s, c_s, specular, specular_exp);
                        break;
                    }
                    case DIFFUSE: {
                        brdf = diffuse;
                        break;
                    }
                    case MIRROR: {
                        printf("this will never happen\n");
                        exit(1);
                    }
                }
            } else {
                // if angle is 0, the whole thing will be 0, so no need to calculate the BRDF
                brdf = Colour(0.0, 0.0, 0.0);
            }
            
            sum = sum + angle * _dw_i[index_i] * _L_i[index_i] * brdf;
            
            //sum = sum + _dw_i[index_i] * Colour(1.0, 1.0, 1.0); // do this for integral of just the angle
            
        }
    }
    //printf("%d. Sum: %f %f %f\n", count, sum[0], sum[1], sum[2]);
    ray.col = sum;
    //ray.col.clamp();
    
    
}

/** Initialize values for this environment map and the sphere being rendered so they don't have to be recomputed when 
  * calculating the sum (integral) for every sphere point 
 **/
void EnvironmentMap::initialize_values() {
    
    _dtheta_i = M_PI / _M;
    _dphi_i = 2*M_PI / _N;
    
    _L_i = new Colour[_M * _N];
    
    _theta_i = new double[_M * _N];
    _phi_i = new double[_M * _N];
    _d_i = new Vector3D[_M * _N];
    _s = new Vector3D[_M * _N];
    _dw_i = new double[_M * _N];
    //Colour sum = Colour(0.0, 0.0, 0.0); // Image normalization (to compare with Ravi's in shlighting.c)
    
    for (int u_i = 0; u_i < _N; u_i++) {
        for (int v_i = 0; v_i < _M; v_i++) {
            
            //printf("initializing (u, v) = (%d, %d)\n", u_i, v_i);
            int index_i = v_i * _N + u_i;

            // Now convert (u_i, v_i) to world coordinates to get d_i = (x_i, y_i, z_i)
            double theta_i = (v_i * M_PI) / _M;
            double phi_i = (u_i * 2 * M_PI) / _N;
            
            _theta_i[index_i] = theta_i;
            _phi_i[index_i] = phi_i;
            
            // Get the intensity at the corresponding point on the environment map
            switch (_fileType) {
                case PPM: {}
                case BMP: {
                    _L_i[index_i] = Colour((int)_rbuffer[index_i] / 255.0, (int)_gbuffer[index_i] / 255.0, (int)_bbuffer[index_i] / 255.0);
                    break;
                }
                case HDR: {
                    _L_i[index_i] = Colour(_floatfile[0][v_i][u_i], _floatfile[1][v_i][u_i], _floatfile[2][v_i][u_i]);
                    break;
                }
            }
            //printf("L_i: %f %f %f\n", _L_i[index_i][0], _L_i[index_i][1], _L_i[index_i][2]);
            
            // (x_i, y_i, z_i) = (-sin(theta)*sin(phi), -cos(theta), sin(theta)*cos(phi))
            Vector3D d_i = Vector3D(-sin(theta_i)*sin(phi_i), -cos(theta_i), sin(theta_i)*cos(phi_i));
            d_i.normalize();
            _d_i[index_i] = d_i;
            
            // Now find s = d_i in sphere's coordinate frame (multiply d_i by world-model matrix)
            _s[index_i] = _worldToObject * _d_i[index_i];
            
            _dw_i[index_i] = sin(theta_i) * _dtheta_i * _dphi_i;
            
            //sum  = sum + (_dw_i[index_i] * _L_i[index_i] * _L_i[index_i]); // Image normalization
            
        }
    }
    //printf("%d. Sum: %f %f %f\n", count, sum[0], sum[1], sum[2]); // Image normalization
    printf("done initializing\n");
    
}

// Given a ray, find the corresponding u, v values (for the mirror reflection direction) in an environment map
void EnvironmentMap::get_u_v(Ray3D& ray, int *u, int*v) {
    
    // normal to sphere = ray.intersection.normal ([0], [1], [2])
    ray.intersection.normal.normalize();
    
    // s should be direction to camera from this point
    //s = (x_c, y_c, z_c) = direction to camera from point on sphere
    Vector3D s = -ray.dir;
    s.normalize();
    
    // Mirror reflection direction
    Vector3D m = -s + (2 * s.dot(ray.intersection.normal) * ray.intersection.normal);
    m.normalize();
    
    // theta = arccos(-y)
    // phi = arctan(x/-z) + pi
    // y and phi are negative because in image coords the positive y-axis starts at the top
    // and goes down whereas in traditional coords the positive y-axis goes up
    // This is as explained on Debevec's page
    // http://gl.ict.usc.edu/Data/HighResProbes/
    double theta = acos(-m[1]);
    double phi = atan2(m[0], -m[2]) + M_PI;
    double u_double = (phi / (2 * M_PI)) * _N;
    double v_double = (theta / (M_PI)) * _M;
    
    // OTHER WAY: this way it's like the env map is facing the sphere instead of behind it
    /*double theta = acos(-m[1]);
    double phi = atan2(m[0], m[2]) - M_PI;
    double u_double = -phi / (2 * M_PI);
    double v_double = theta / (M_PI);*/
    
    //printf("%f, %f\n", u, v);
    
    // Round values to ints
    int u_int = (int) round(u_double);
    int v_int = (int) round(v_double);
    // If u or v was close to the max value and got rounded above it, subtract one
    // so it doesn't go beyond the max value
    if (u_int >= _N) {
        u_int = _N - 1;
    }
    if (v_int >= _M) {
        v_int = _M - 1;
    }
    //printf("(%d, %d)\n", u_int, v_int);
    (*u) = u_int;
    (*v) = v_int;
    
}
