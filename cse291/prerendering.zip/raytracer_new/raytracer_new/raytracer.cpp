/***********************************************************
     Starter code for Assignment 3

     This code was originally written by Jack Wang for
		    CSC418, SPRING 2005

	
 
    This code has been extended and modified by Ailie Fraser.

***********************************************************/


#include "raytracer.h"
#include "bmp_io.h"
#include <cmath>
#include <iostream>
#include <cstdlib>

float SPECREF = 0.3;
int MAXDEPTH = 2;

// Factor by which all outgoing images will be multiplied
int SCALEFAC = 1000;
//int SCALEFAC = 255;

Raytracer::Raytracer(Colour dif, Colour spec, double spec_exp) : _lightSource(NULL), _env_map(NULL), diffuse(dif), specular(spec), specular_exp(spec_exp) {
	_root = new SceneDagNode();
}

Raytracer::~Raytracer() {
	delete _root;
}

SceneDagNode* Raytracer::addObject( SceneDagNode* parent, 
		SceneObject* obj, Material* mat ) {
	SceneDagNode* node = new SceneDagNode( obj, mat );
	node->parent = parent;
	node->next = NULL;
	node->child = NULL;
	
	// Add the object to the parent's child list, this means
	// whatever transformation applied to the parent will also
	// be applied to the child.
	if (parent->child == NULL) {
		parent->child = node;
	}
	else {
		parent = parent->child;
		while (parent->next != NULL) {
			parent = parent->next;
		}
		parent->next = node;
	}
	
	return node;;
}

LightListNode* Raytracer::addLightSource( LightSource* light ) {
	LightListNode* tmp = _lightSource;
	_lightSource = new LightListNode( light, tmp );
	return _lightSource;
}

void Raytracer::addEnvironmentMap(char *filename, Matrix4x4 worldToObject, filetype fileType) {
    _env_map = new EnvironmentMap(filename, worldToObject, fileType, specular_exp, specular, diffuse);
    
}

void Raytracer::removeEnvironmentMap() {
    delete _env_map;
    _env_map = NULL;
}

void Raytracer::rotate( SceneDagNode* node, char axis, double angle ) {
	Matrix4x4 rotation;
	double toRadian = 2*M_PI/360.0;
	int i;
	
	for (i = 0; i < 2; i++) {
		switch(axis) {
			case 'x':
				rotation[0][0] = 1;
				rotation[1][1] = cos(angle*toRadian);
				rotation[1][2] = -sin(angle*toRadian);
				rotation[2][1] = sin(angle*toRadian);
				rotation[2][2] = cos(angle*toRadian);
				rotation[3][3] = 1;
			break;
			case 'y':
				rotation[0][0] = cos(angle*toRadian);
				rotation[0][2] = sin(angle*toRadian);
				rotation[1][1] = 1;
				rotation[2][0] = -sin(angle*toRadian);
				rotation[2][2] = cos(angle*toRadian);
				rotation[3][3] = 1;
			break;
			case 'z':
				rotation[0][0] = cos(angle*toRadian);
				rotation[0][1] = -sin(angle*toRadian);
				rotation[1][0] = sin(angle*toRadian);
				rotation[1][1] = cos(angle*toRadian);
				rotation[2][2] = 1;
				rotation[3][3] = 1;
			break;
		}
		if (i == 0) {
		    node->trans = node->trans*rotation; 	
			angle = -angle;
		} 
		else {
			node->invtrans = rotation*node->invtrans; 
		}	
	}
}

void Raytracer::translate( SceneDagNode* node, Vector3D trans ) {
	Matrix4x4 translation;
	
	translation[0][3] = trans[0];
	translation[1][3] = trans[1];
	translation[2][3] = trans[2];
	node->trans = node->trans*translation; 	
	translation[0][3] = -trans[0];
	translation[1][3] = -trans[1];
	translation[2][3] = -trans[2];
	node->invtrans = translation*node->invtrans; 
}

void Raytracer::scale( SceneDagNode* node, Point3D origin, double factor[3] ) {
	Matrix4x4 scale;
	
	scale[0][0] = factor[0];
	scale[0][3] = origin[0] - factor[0] * origin[0];
	scale[1][1] = factor[1];
	scale[1][3] = origin[1] - factor[1] * origin[1];
	scale[2][2] = factor[2];
	scale[2][3] = origin[2] - factor[2] * origin[2];
	node->trans = node->trans*scale; 	
	scale[0][0] = 1/factor[0];
	scale[0][3] = origin[0] - 1/factor[0] * origin[0];
	scale[1][1] = 1/factor[1];
	scale[1][3] = origin[1] - 1/factor[1] * origin[1];
	scale[2][2] = 1/factor[2];
	scale[2][3] = origin[2] - 1/factor[2] * origin[2];
	node->invtrans = scale*node->invtrans; 
}

Matrix4x4 Raytracer::initInvViewMatrix( Point3D eye, Vector3D view, 
		Vector3D up ) {
	Matrix4x4 mat; 
	Vector3D w;
	view.normalize();
	up = up - up.dot(view)*view;
	up.normalize();
	w = view.cross(up);

	mat[0][0] = w[0];
	mat[1][0] = w[1];
	mat[2][0] = w[2];
	mat[0][1] = up[0];
	mat[1][1] = up[1];
	mat[2][1] = up[2];
	mat[0][2] = -view[0];
	mat[1][2] = -view[1];
	mat[2][2] = -view[2];
	mat[0][3] = eye[0];
	mat[1][3] = eye[1];
	mat[2][3] = eye[2];

	return mat; 
}

void Raytracer::traverseScene( SceneDagNode* node, Ray3D& ray ) {
	SceneDagNode *childPtr;

	// Applies transformation of the current node to the global
	// transformation matrices.
	_modelToWorld = _modelToWorld*node->trans;
	_worldToModel = node->invtrans*_worldToModel; 
	if (node->obj) {
		// Perform intersection.
		if (node->obj->intersect(ray, _worldToModel, _modelToWorld)) {
			ray.intersection.mat = node->mat;
		}
	}
	// Traverse the children.
	childPtr = node->child;
	while (childPtr != NULL) {
		traverseScene(childPtr, ray);
		childPtr = childPtr->next;
	}

	// Removes transformation of the current node from the global
	// transformation matrices.
	_worldToModel = node->trans*_worldToModel;
	_modelToWorld = _modelToWorld*node->invtrans;
}

void Raytracer::computeShading( Ray3D& ray ) {
	LightListNode* curLight = _lightSource;
	for (;;) {
		if (curLight == NULL) break;
		// Each lightSource provides its own shading function.

		// Implement shadows here if needed.
		// Cast ray toward light source
		/*Ray3D lightRay;
		lightRay.origin = ray.intersection.point;
		lightRay.dir = curLight->light->get_position() - ray.intersection.point;
		traverseScene(_root, lightRay);
		printf("t value is %f\n", lightRay.intersection.t_value);
		if ((lightRay.intersection.t_value < 1) && (lightRay.intersection.t_value > 0)) {
			curLight->light->shadeAmbient(ray);
		} else {
			curLight->light->shade(ray);
		}*/
		curLight->light->shade(ray, specular, specular_exp, diffuse, currentBRDF);
		curLight = curLight->next;
	}
}

void Raytracer::computeShadingEnvMap( Ray3D& ray) {
    // Find the point on the environment map this ray corresponds to and shade the ray accordingly.
    
    switch (currentBRDF) {
        case PHONG:
        case DIFFUSE:
        case TORRANCE: {
            _env_map->shade(ray, currentBRDF);
            break;
        }
        case MIRROR: {
            _env_map->shade_mirror(ray);
            break;
        }
    }
    
}

void Raytracer::initPixelBuffer() {
	int numbytes = _scrWidth * _scrHeight * sizeof(unsigned char);
	_rbuffer = new unsigned char[numbytes];
	_gbuffer = new unsigned char[numbytes];
	_bbuffer = new unsigned char[numbytes];
    _emptybuffer = new unsigned char[numbytes];
	for (int i = 0; i < _scrHeight; i++) {
		for (int j = 0; j < _scrWidth; j++) {
			_rbuffer[i*_scrWidth+j] = 0;
			_gbuffer[i*_scrWidth+j] = 0;
			_bbuffer[i*_scrWidth+j] = 0;
            _emptybuffer[i*_scrWidth+j] = 0;
		}
	}
}

void Raytracer::flushPixelBuffer( char *file_name ) {
	bmp_write( file_name, _scrWidth, _scrHeight, _rbuffer, _gbuffer, _bbuffer );
	delete _rbuffer;
	delete _gbuffer;
	delete _bbuffer;
    delete _emptybuffer;
}

void Raytracer::flushPixelBufferSeparate( char *file_name) {
    
    char * rfile_name = new char[std::strlen(file_name)+std::strlen("R_")+1];
    std::strcpy(rfile_name,"R_");
    std::strcat(rfile_name,file_name);
    
    char * gfile_name = new char[std::strlen(file_name)+std::strlen("G_")+1];
    std::strcpy(gfile_name,"G_");
    std::strcat(gfile_name,file_name);
    
    char * bfile_name = new char[std::strlen(file_name)+std::strlen("B_")+1];
    std::strcpy(bfile_name,"B_");
    std::strcat(bfile_name,file_name);
    
    bmp_write( rfile_name, _scrWidth, _scrHeight, _rbuffer, _emptybuffer, _emptybuffer );
    bmp_write( gfile_name, _scrWidth, _scrHeight, _emptybuffer, _gbuffer, _emptybuffer );
    bmp_write( bfile_name, _scrWidth, _scrHeight, _emptybuffer, _emptybuffer, _bbuffer );
    delete _rbuffer;
    delete _gbuffer;
    delete _bbuffer;
    delete _emptybuffer;
}

Colour Raytracer::shadeRay( Ray3D& ray, int depth, bool envLighting ) {
	Colour col(0.0, 0.0, 0.0); 
	traverseScene(_root, ray); 
	
	// Don't bother shading if the ray didn't hit 
	// anything.
	if (!ray.intersection.none) {
        if (envLighting) {
            computeShadingEnvMap(ray);
        } else {
            computeShading(ray);
        }
		col = ray.col; 

	}

	return col; 
}	

void Raytracer::render( int width, int height, Point3D eye, Vector3D view, 
		Vector3D up, double fov, char* fileName, bool envLighting ) {
    // envLighting true for lighting under env map, false for point light
	Matrix4x4 viewToWorld;
	_scrWidth = width;
	_scrHeight = height;
	double factor = (double(height)/2)/tan(fov*M_PI/360.0);

	initPixelBuffer();
	viewToWorld = initInvViewMatrix(eye, view, up);
    double max = 0.0;
	// Construct a ray for each pixel.
	for (int i = 0; i < _scrHeight; i++) {
		for (int j = 0; j < _scrWidth; j++) {
			// Sets up ray origin and direction in view space, 
			// image plane is at z = -1.
			Point3D origin(0, 0, 0);
			Point3D imagePlane;
			imagePlane[0] = (-double(width)/2 + 0.5 + j)/factor;
			imagePlane[1] = (-double(height)/2 + 0.5 + i)/factor;
			imagePlane[2] = -1;

			// Convert ray to world space and call 
			// shadeRay(ray) to generate pixel colour. 	
			Ray3D ray;
			ray.origin = viewToWorld*origin;
			ray.dir = viewToWorld * (imagePlane - origin);
			ray.dir.normalize();

			Colour col = shadeRay(ray, 1, envLighting);
            if (col[0] > max) {
                max = col[0];
            }
            if (col[1] > max) {
                max = col[1];
            }
            if (col[2] > max) {
                max = col[2];
            }
            
            Vector3D finalcol(int(col[0]*SCALEFAC), int(col[1]*SCALEFAC), int(col[2]*SCALEFAC));
            for (int i = 0; i < 3; i++) {
                if (finalcol[i] > 255) finalcol[i] = 255;
                else if (finalcol[i] < 0) finalcol[i] = 0;
            }
            
            _rbuffer[i*width+j] = int(finalcol[0]);
            _gbuffer[i*width+j] = int(finalcol[1]);
            _bbuffer[i*width+j] = int(finalcol[2]);

			//_rbuffer[i*width+j] = int(col[0]*255);
			//_gbuffer[i*width+j] = int(col[1]*255);
			//_bbuffer[i*width+j] = int(col[2]*255);

		}
	}
    printf("max = %f\n", max);
    
    switch (currentBRDF) {
        case PHONG: {
        }
        case MIRROR: {
        }
        case TORRANCE: {
            flushPixelBuffer(fileName);
            break;
        }
        case DIFFUSE: {
            printf("done calculating, gonna write files\n");
            flushPixelBufferSeparate(fileName);
            break;
        }
    }
    
	
}

void Raytracer::update_specular_exp(double new_spec) {
    specular_exp = new_spec;
    _env_map->specular_exp = new_spec;
}

void Raytracer::update_specular(Colour new_spec) {
    specular = new_spec;
    _env_map->specular = new_spec;
}

void Raytracer::update_diffuse(Colour new_dif) {
    diffuse = new_dif;
    _env_map->diffuse = new_dif;
}

int main(int argc, char* argv[])
{
	// Build your scene and setup your camera here, by calling
	// functions from Raytracer.  The code here sets up an example
	// scene and renders it from two different view points, DO NOT
	// change this if you're just implementing part one of the 
	// assignment.  
	Raytracer raytracer(Colour(0.0, 0.0, 0.0), Colour(1.0, 1.0, 1.0), 0.0);
	int width = 320;
	int height = 240;

	if (argc == 3) {
		width = atoi(argv[1]);
		height = atoi(argv[2]);
	}

	// Camera parameters.
	Point3D eye(0, 0, 1);
	Vector3D view(0, 0, -1);
	Vector3D up(0, 1, 0);
	double fov = 60;

	// Defines a point light source.
	raytracer.addLightSource( new PointLight(Point3D(0, 0, 5), Colour(0.9, 0.9, 0.9) ) );
    

	// Add a unit sphere into the scene with material mat.
	SceneDagNode* sphere = raytracer.addObject( new UnitSphere(), nullptr );
	
	// Apply some transformations to the unit sphere.
	raytracer.translate(sphere, Vector3D(0, 0, -2));

    
    //Upload environment map
    raytracer.addEnvironmentMap("myfloat.out", sphere->invtrans, HDR);
    char buffer[50];
    
    raytracer.currentBRDF = MIRROR;
    raytracer.render(width, height, eye, view, up, fov, "mirror.bmp", true);
    
    
    // Render using env maps from Ravi's code
    /*raytracer.removeEnvironmentMap();

    const int num_exponents = 20;
    int exponents[num_exponents] = {0, 5, 10, 15, 25, 50, 75, 100, 150, 200, 300, 400, 500, 750, 1000, 1500, 2000, 3000, 4000, 5000};
    
    for (int i=0; i<20; i++) {
        char loadfilename[50];
        sprintf(loadfilename, "myoutput%d.ppm", exponents[i]);
        raytracer.addEnvironmentMap(loadfilename, sphere->invtrans, PPM);
        
        sprintf(buffer, "ravi_env_%d.bmp", exponents[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, true);
        printf("Rendered phong sphere under Ravi's env map with exponent %d\n", exponents[i]);
        raytracer.removeEnvironmentMap();
    }*/
    
    // Render specular phong images
    raytracer.currentBRDF = PHONG;
    const int num_exponents = 20;
    double exponents[num_exponents] = {0.0, 5.0, 10.0, 15.0, 25.0, 50.0, 75.0, 100.0, 150.0, 200.0, 300.0, 400.0, 500.0, 750.0, 1000.0, 1500.0, 2000.0, 3000.0, 4000.0, 5000.0};
 
    for (int i=0; i<num_exponents; i++) {
    
        raytracer.update_specular_exp(exponents[i]);

        sprintf(buffer, "phong_env_%d.bmp", (int)exponents[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, true);
        printf("Rendered phong sphere under env map with exponent %f\n", exponents[i]);
        
        sprintf(buffer, "phong_light_%d.bmp", (int)exponents[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, false);
        printf("Rendered phong sphere under point light with exponent %f\n", exponents[i]);
    }
    
    // Render specular Torrance-Sparrow images
    const int num_sigmas = 20;
    double sigmas[num_sigmas] = { 0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32 };
    
    raytracer.currentBRDF = TORRANCE;
    for (int i=0; i<num_sigmas; i++) {
        raytracer.update_specular_exp(sigmas[i]);
        
        sprintf(buffer, "torrance_env_%f.bmp", sigmas[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, true);
        printf("Rendered torrance sphere under env map with exponent %f\n", sigmas[i]);
        
        sprintf(buffer, "torrance_light_%f.bmp", sigmas[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, false);
        printf("Rendered torrance sphere under point light with exponent %f\n", sigmas[i]);
    }
 
    // Render diffuse images
    const int num_diffuses = 20;
    double diffuses[num_diffuses] = { 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0,
        0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95 };
    
    raytracer.currentBRDF = DIFFUSE;
    for (int i=9; i<10; i++) {
        raytracer.update_diffuse(Colour(diffuses[i], diffuses[i], diffuses[i]));
        
        sprintf(buffer, "diffuse_env_%f.bmp", diffuses[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, true);
        printf("Rendered diffuse sphere under env map with value %f\n", diffuses[i]);
        
        sprintf(buffer, "diffuse_light_%f.bmp", diffuses[i]);
        raytracer.render(width, height, eye, view, up, fov, buffer, false);
        printf("Rendered diffuse sphere under point light with value %f\n", diffuses[i]);
        
    }
    
	return 0;
}

