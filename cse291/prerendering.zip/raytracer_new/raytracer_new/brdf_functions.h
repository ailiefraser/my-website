//
//  brdf_functions.h
//  raytracer_new
//
//  Created by Ailie Fraser on 2015-02-04.
//  Copyright (c) 2015 Ailie Fraser. All rights reserved.
//

#ifndef __raytracer_new__brdf_functions__
#define __raytracer_new__brdf_functions__

#include "util.h"

Colour phong_specular(Vector3D s, Vector3D n, Vector3D c, Colour specular, double specular_exp);
Colour phong_specular_unnormalized(Vector3D s, Vector3D n, Vector3D c, Colour specular, double specular_exp);
Colour torrance_specular(Vector3D s, Vector3D n, Vector3D c, Colour specular, double sigma);

#endif /* defined(__raytracer_new__brdf_functions__) */
