/***********************************************************
     Starter code for Assignment 3

     This code was originally written by Jack Wang for
		    CSC418, SPRING 2005

		implements light_source.h
 
    This code has been extended and modified by Ailie Fraser.

***********************************************************/

#include <cmath>
#include "light_source.h"
#include "brdf_functions.h"

void PointLight::shade( Ray3D& ray, Colour specular_k, double specular_exp, Colour diffuse_k, BRDFmodel brdf_model) {
	// Implement this function to fill in values for ray.col 
	// using phong shading.  Make sure your vectors are normalized, and
	// clamp colour values to 1.0.
	//
	// It is assumed at this point that the intersection information in ray 
	// is available.  So be sure that traverseScene() is called on the ray 
	// before this function.  

	// Make sure our vectors are normalized.
	ray.dir.normalize();
	ray.intersection.normal.normalize();
    
	// s = vector going from the point to the light source
	Vector3D s = _pos - ray.intersection.point;
	s.normalize();

    Vector3D c = -ray.dir;
    c.normalize();
    
    
    // Use specular phong only
    //ray.col = pow(std::max(0.0, m.dot(-ray.dir)), specular_exp) * _col_specular * specular_k;
    
    Colour result;
    switch (brdf_model) {
        case PHONG: {
            result = phong_specular_unnormalized(s, ray.intersection.normal, c, specular_k, specular_exp);
            break;
        }
        case TORRANCE: {
            result = torrance_specular(s, ray.intersection.normal, c, specular_k, specular_exp);
            break;
        }
        case DIFFUSE: {
            result = std::max(0.0, s.dot(ray.intersection.normal)) * diffuse_k;
            break;
        }
    }
    result = s.dot(ray.intersection.normal) * result * _col_specular;
    
    ray.col = result;
	ray.col.clamp();


}

void PointLight::shadeAmbient( Ray3D& ray ) {
	Colour ambient = _col_ambient * ray.intersection.mat->ambient;
	ray.col = ambient;
	ray.col.clamp();
}