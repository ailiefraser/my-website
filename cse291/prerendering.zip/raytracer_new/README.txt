Pre-rendering code
By Ailie Fraser

This code was written and built in XCode on a Mac. The executable can be found in the bin folder. All source code is in the raytracer_new folder. The environment map that gets loaded is myfloat.out. 
The majority of the code I wrote is in the files raytracer_new.cpp, brdf_functions.cpp and environment_map.cpp.