Editing Interface
By Ailie Fraser

The main MATLAB function to be run is interface.m, in the program folder.
All pre-rendered images are in the sphere_pics folder.