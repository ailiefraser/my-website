
function interface()

    height = 240;
    width = 320;
    
    % number to append to next saved image
    written_image_count = 1;
    
    specular_exp_i = 2;
    specular_i = 21;
    diffuser_i = 1;
    diffuseb_i = 1;
    diffuseg_i = 1;
    diffuser_indices = ones(height, width);
    diffuseb_indices = ones(height, width);
    diffuseg_indices = ones(height, width);
    specular_exp_indices = ones(height, width) .* 2;
    specular_indices = ones(height, width) .* 21;
    scalefac = 1;

    
    % Get set when drawing diffuse
    new_r = 0;
    new_g = 0;
    new_b = 0;
    
    % For brush drawing
    % Brush radius
    radius = 25;
    % Standard deviation of Gaussian = spread of brush
    sigma = 15;
    
    env_display_img = uint8(zeros(height, width, 3));
    light_display_img = uint8(zeros(height, width, 3));
    
    env_img_diffuser = zeros(height, width, 'uint8');
    light_img_diffuser = zeros(height, width, 'uint8');
    env_img_diffuseg = zeros(height, width, 'uint8');
    light_img_diffuseg = zeros(height, width, 'uint8');
    env_img_diffuseb = zeros(height, width, 'uint8');
    light_img_diffuseb = zeros(height, width, 'uint8');
    
    env_img_spec = zeros(height, width, 3, 'uint8');
    light_img_spec = zeros(height, width, 3, 'uint8');
    
    specular_exponents = [0, 5, 10, 15, 25, 50, 75, 100, 150, 200, 300, ...
        400, 500, 750, 1000, 1500, 2000, 3000, 4000, 5000];
    sigmas = [0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.1, 0.12, ...
        0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32];
    current_exp_list = specular_exponents;
    num_exponents = 20;
    
    intensity_values = [0.0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, ...
        0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0];
    num_intensities = size(intensity_values, 2);
    intensity_step = 1 / (num_intensities - 1);

    dirpath = '../sphere_pics/hdr_grace/OK/';
    
    brdf_model = 'Phong';
    diffuser_file = 'DIFFUSE_R/R_diffuse_';
    diffuseg_file = 'DIFFUSE_G/G_diffuse_';
    diffuseb_file = 'DIFFUSE_B/B_diffuse_';
    
%     if strcmp(brdf_model, 'Phong')
%         light_file = 'PHONG/phong_';
%         env_file = light_file;
%         if specular_exp_i <= 9 && specular_exp_i > 1
%             env_file = 'RAVI_PHONG/ravi_';
%         end
%     else
%         light_file = 'TORRANCE/torrance_';
%         env_file = light_file;
%     end
    
    diffuser_env_images = zeros(height, width, num_intensities, 'uint8');
    diffuseg_env_images = zeros(height, width, num_intensities, 'uint8');
    diffuseb_env_images = zeros(height, width, num_intensities, 'uint8');
    diffuser_light_images = zeros(height, width, num_intensities, 'uint8');
    diffuseg_light_images = zeros(height, width, num_intensities, 'uint8');
    diffuseb_light_images = zeros(height, width, num_intensities, 'uint8');
    load_diffuse_images();
    
    specular_env_images_phong = zeros(height, width, 3, num_exponents, 'uint8');
    specular_light_images_phong = zeros(height, width, 3, num_exponents, 'uint8');
    specular_env_images_tor = zeros(height, width, 3, num_exponents, 'uint8');
    specular_light_images_tor = zeros(height, width, 3, num_exponents, 'uint8');
    load_specular_images();
    
    fontsize = 14;

    fig1 = figure(1);
    set(fig1, 'Position', [100, 100, 1000, 800]);
    %set(gcf, 'KeyPressFcn', @diffuseKeyPress);
    subplot(2, 2, 1);
    title('Environment map');
    
    subplot(2, 2, 2);
    title('Point light source');
    
    %subplot(2, 2, [3 4]);
    %set(fig1, 'name', 'Environment Map');

    %fig2 = figure(2);
    %set(fig2, 'name', 'Point light source');

    %fig3 = figure(3);
    %set(fig3, 'name', 'Edit Reflectance');

    % Create slider
    spec_exp_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',20, 'Value',specular_exp_i, 'SliderStep', [1/19 1/19],...
        'Position', [130 350 200 20], 'Callback', @update_specular_exp); 
    spec_exp_header = uicontrol('Style','text', 'Position',[130 375 200 20], 'String','Specular roughness', 'FontSize', fontsize);
    spec_exp_display = uicontrol('Style','text', 'Position',[130 335 200 20], 'String',num2str(current_exp_list(specular_exp_i)), 'FontSize', fontsize);
    
    specular_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',21, 'Value',specular_i, 'SliderStep', [intensity_step intensity_step],...
        'Position', [130 250 200 20], 'Callback', @update_specular); 
    specular_header = uicontrol('Style','text', 'Position',[130 275 200 20], 'String','Specular Intensity', 'FontSize', fontsize);
    specular_display = uicontrol('Style','text', 'Position',[130 235 200 20], 'String',num2str(intensity_values(specular_i)), 'FontSize', fontsize);
    
    scalefac_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',10, 'Value',scalefac, 'SliderStep', [1/9 1/9],...
        'Position', [130 150 200 20], 'Callback', @update_scalefac); 
    scalefac_header = uicontrol('Style','text', 'Position',[130 175 200 20], 'String','Overall Scaling', 'FontSize', fontsize);
    scalefac_display = uicontrol('Style','text', 'Position',[130 135 200 20], 'String',num2str(scalefac), 'FontSize', fontsize);
    
    phong_brdf_box = uicontrol('Style', 'radiobutton', 'String', 'Phong', 'Position', [130 50 70 20], 'Callback', @change_brdf, 'Value', 1);
    torrance_brdf_box = uicontrol('Style', 'radiobutton', 'String', 'Torrance-Sparrow', 'Position', [210 50 110 20],  'Callback', @change_brdf);
    brdf_header = uicontrol('Style','text', 'Position',[130 75 200 20], 'String','BRDF Model', 'FontSize', fontsize);
    
    spec_exp_brush_header = uicontrol('Style','text', 'Position',[350 375 200 20], 'String','Adjust Highlight Spread', 'FontSize', fontsize);
    spec_exp_brush_button = uicontrol('Style', 'pushbutton', 'String', 'Draw', 'Position', [400 350 90 20], 'Callback', @draw_specular_exp);
    
    blur_brush_header = uicontrol('Style','text', 'Position',[350 275 200 20], 'String','Blur/Sharpen Brushes', 'FontSize', fontsize);
    blur_brush_button = uicontrol('Style', 'pushbutton', 'String', 'Blur', 'Position', [350 250 90 20], 'Callback', @draw_blur);
    sharpen_brush_button = uicontrol('Style', 'pushbutton', 'String', 'Sharpen', 'Position', [460 250 90 20], 'Callback', @draw_sharpen);

    spec_brush_header = uicontrol('Style','text', 'Position',[350 175 200 20], 'String','Highlight Intensity Brush', 'FontSize', fontsize);
    spec_brush_button = uicontrol('Style', 'pushbutton', 'String', 'Increase', 'Position', [350 150 90 20], 'Callback', {@draw_specular_intensity,true});
    spec_brush_button = uicontrol('Style', 'pushbutton', 'String', 'Decrease', 'Position', [460 150 90 20], 'Callback', {@draw_specular_intensity,false});
    
    save_button = uicontrol('Style', 'pushbutton', 'String', 'Save Image', 'Position', [400 75 90 20], 'Callback', @save_image);
    
    diffuser_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',21, 'Value',diffuser_i, 'SliderStep', [intensity_step intensity_step],...
        'Position', [640 350 200 20], 'Callback', @update_diffuser); 
    diffuser_header = uicontrol('Style','text', 'Position',[640 375 200 20], 'String','Diffuse Red', 'FontSize', fontsize);
    diffuser_display = uicontrol('Style','text', 'Position',[640 335 200 20], 'String',num2str(intensity_values(diffuser_i)), 'FontSize', fontsize);
    
    diffuseg_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',21, 'Value',diffuseg_i, 'SliderStep', [intensity_step intensity_step],...
        'Position', [640 250 200 20], 'Callback', @update_diffuseg); 
    diffuseg_header = uicontrol('Style','text', 'Position',[640 275 200 20], 'String','Diffuse Green', 'FontSize', fontsize);
    diffuseg_display = uicontrol('Style','text', 'Position',[640 235 200 20], 'String',num2str(intensity_values(diffuseg_i)), 'FontSize', fontsize);
    
    diffuseb_slider = uicontrol('Style', 'slider', 'Min',1, 'Max',21, 'Value',diffuseb_i, 'SliderStep', [intensity_step intensity_step],...
        'Position', [640 150 200 20], 'Callback', @update_diffuseb); 
    diffuseb_header = uicontrol('Style','text', 'Position',[640 175 200 20], 'String','Diffuse Blue', 'FontSize', fontsize);
    diffuseb_display = uicontrol('Style','text', 'Position',[640 135 200 20], 'String',num2str(intensity_values(diffuseb_i)), 'FontSize', fontsize);
    
    change_color_button = uicontrol('Style', 'pushbutton', 'String', 'Change Overall', 'Position', [640 50 90 20], 'Callback', @change_colour);
    change_color_header = uicontrol('Style','text', 'Position',[640 75 200 20], 'String','Edit Diffuse Color', 'FontSize', fontsize);
    
    draw_diffuse_button = uicontrol('Style', 'pushbutton', 'String', 'Draw Colour', 'Position', [740 50 70 20], 'Callback', @draw_diffuse);
    
    draw();
    
    function draw()
        
        set(spec_exp_display, 'String', num2str(current_exp_list(specular_exp_i)));
        set(specular_display, 'String', num2str(intensity_values(specular_i)));
        set(scalefac_display, 'String', num2str(scalefac));
        set(diffuser_display, 'String', num2str(intensity_values(diffuser_i)));
        set(diffuseg_display, 'String', num2str(intensity_values(diffuseg_i)));
        set(diffuseb_display, 'String', num2str(intensity_values(diffuseb_i)));
        
%         if strcmp(brdf_model, 'Phong')
%             light_file = 'PHONG/phong_';
%             env_file = light_file;
%             if specular_exp_i <= 9 && specular_exp_i > 1
%                 env_file = 'RAVI_PHONG/ravi_';
%             end
%             %env_img_spec = imread(strcat(dirpath, env_file, 'env_', num2str(current_exp_list(specular_exp_i)), '.bmp'));
%             %light_img_spec = imread(strcat(dirpath, light_file, 'light_', num2str(current_exp_list(specular_exp_i)), '.bmp'));
% 
%         else
%             light_file = 'TORRANCE/torrance_';
%             env_file = light_file;
%             %env_img_spec = imread(strcat(dirpath, env_file, 'env_', num2str(current_exp_list(specular_exp_i), '%f'), '.bmp'));
%             %light_img_spec = imread(strcat(dirpath, light_file, 'light_', num2str(current_exp_list(specular_exp_i), '%f'), '.bmp'));
% 
%         end
        
        display_specular();
        env_display_img(:,:,1) = uint8(double(env_img_spec(:,:,1)) .*intensity_values(specular_indices));
        env_display_img(:,:,2) = uint8(double(env_img_spec(:,:,2)) .*intensity_values(specular_indices));
        env_display_img(:,:,3) = uint8(double(env_img_spec(:,:,3)) .*intensity_values(specular_indices));
        light_display_img(:,:,1) = uint8(double(light_img_spec(:,:,1)) .*intensity_values(specular_indices));
        light_display_img(:,:,2) = uint8(double(light_img_spec(:,:,2)) .*intensity_values(specular_indices));
        light_display_img(:,:,3) = uint8(double(light_img_spec(:,:,3)) .*intensity_values(specular_indices));
        % Add diffuse images
        display_diffuse();
        env_display_img(:,:,1) = env_display_img(:,:,1) + env_img_diffuser;
        env_display_img(:,:,2) = env_display_img(:,:,2) + env_img_diffuseg;
        env_display_img(:,:,3) = env_display_img(:,:,3)+ env_img_diffuseb;
        light_display_img(:,:,1) = light_display_img(:,:,1) + light_img_diffuser;
        light_display_img(:,:,2) = light_display_img(:,:,2) + light_img_diffuseg;
        light_display_img(:,:,3) = light_display_img(:,:,3) + light_img_diffuseb;
        
        env_display_img = env_display_img*scalefac;
        figure(1);
        subplot(2, 2, 1, 'replace');
        imshow(env_display_img);
        imwrite(env_display_img, 'testenv.bmp');
        subplot(2, 2, 2, 'replace');
        imshow(light_display_img);
        imwrite(light_display_img, 'testlight.bmp');
        %figure(2);
        %imshow(light_display_img);
        
    end

    % Read in all specular images
    function load_specular_images()
        
        for i = 1:num_exponents

            light_file_phong = 'PHONG/phong_';
            env_file_phong = light_file_phong;
            if i <= 9 && i > 1
                env_file_phong = 'RAVI_PHONG/ravi_';
            end
            temp_env_phong = imread(strcat(dirpath, env_file_phong, 'env_', num2str(specular_exponents(i)), '.bmp'));
            temp_light_phong = imread(strcat(dirpath, light_file_phong, 'light_', num2str(specular_exponents(i)), '.bmp'));

            light_file_tor = 'TORRANCE/torrance_';
            env_file_tor = light_file_tor;
            temp_env_tor = imread(strcat(dirpath, env_file_tor, 'env_', num2str(sigmas(i), '%f'), '.bmp'));
            temp_light_tor = imread(strcat(dirpath, light_file_tor, 'light_', num2str(sigmas(i), '%f'), '.bmp'));

            specular_env_images_phong(:,:,:,i) = temp_env_phong(:,:,:);
            specular_light_images_phong(:,:,:,i) = temp_light_phong(:,:,:);
            
            specular_env_images_tor(:,:,:,i) = temp_env_tor(:,:,:);
            specular_light_images_tor(:,:,:,i) = temp_light_tor(:,:,:);
        end
    end

    % Read in all diffuse images
    function load_diffuse_images()
        % Red
        for i = 2:num_intensities
            temp = imread(strcat(dirpath, diffuser_file, 'env_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuser_env_images(:,:,i) = temp(:,:,1); % Red channel only
            temp = imread(strcat(dirpath, diffuser_file, 'light_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuser_light_images(:,:,i) = temp(:,:,1);

        end
        % Green
        for i = 2:num_intensities
            temp = imread(strcat(dirpath, diffuseg_file, 'env_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuseg_env_images(:,:,i) = temp(:,:,2); % G channel only
            temp = imread(strcat(dirpath, diffuseg_file, 'light_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuseg_light_images(:,:,i) = temp(:,:,2);

        end
        % Blue
        for i = 2:num_intensities
            temp = imread(strcat(dirpath, diffuseb_file, 'env_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuseb_env_images(:,:,i) = temp(:,:,3); % B channel only
            temp = imread(strcat(dirpath, diffuseb_file, 'light_', num2str(intensity_values(i), '%f'), '.bmp'));
            diffuseb_light_images(:,:,i) = temp(:,:,3);

        end
        
    end

    % Calculate what specular exp should be displayed at every pixel
    function display_specular()
        for i = 1:height
            for j = 1:width
                if strcmp(brdf_model, 'Phong')
                    env_img_spec(i, j, :) = specular_env_images_phong(i, j, :, specular_exp_indices(i, j));
                    light_img_spec(i, j, :) = specular_light_images_phong(i, j, :, specular_exp_indices(i, j));
                else
                    env_img_spec(i, j, :) = specular_env_images_tor(i, j, :, specular_exp_indices(i, j));
                    light_img_spec(i, j, :) = specular_light_images_tor(i, j, :, specular_exp_indices(i, j));
                end
            end
        end
    end
        
    % Calculate what diffuse value should be displayed at every pixel
    function display_diffuse()

        for i = 1:height
            for j = 1:width
                env_img_diffuser(i, j) = diffuser_env_images(i, j, diffuser_indices(i, j));
                light_img_diffuser(i, j) = diffuser_light_images(i, j, diffuser_indices(i, j));

                env_img_diffuseg(i, j) = diffuseg_env_images(i, j, diffuseg_indices(i, j));
                light_img_diffuseg(i, j) = diffuseg_light_images(i, j, diffuseg_indices(i, j));

                env_img_diffuseb(i, j) = diffuseb_env_images(i, j, diffuseb_indices(i, j));
                light_img_diffuseb(i, j) = diffuseb_light_images(i, j, diffuseb_indices(i, j));
            end
        end
    end
    
    
    function update_specular_exp(source,callbackdata)
        specular_exp_i = round(get(source, 'Value'));
        specular_exp_indices(:,:,:) = specular_exp_i;
        set(spec_exp_display, 'String', num2str(current_exp_list(specular_exp_i)));
        draw();
    end

    function update_diffuser(source,callbackdata)
        diffuser_i = round(get(source, 'Value'));
        diffuser_indices(:,:,:) = diffuser_i;
        set(diffuser_display, 'String', num2str(intensity_values(diffuser_i)));
        draw();
    end

    function update_diffuseg(source,callbackdata)
        diffuseg_i = round(get(source, 'Value'));
        diffuseg_indices(:,:,:) = diffuseg_i;
        set(diffuseg_display, 'String', num2str(intensity_values(diffuseg_i)));
        draw();
    end

    function update_diffuseb(source,callbackdata)
        diffuseb_i = round(get(source, 'Value'));
        diffuseb_indices(:,:,:) = diffuseb_i;
        set(diffuseb_display, 'String', num2str(intensity_values(diffuseb_i)));
        draw();
    end

    function update_scalefac(source,callbackdata)
        scalefac = round(get(source, 'Value'));
        set(scalefac_display, 'String', num2str(scalefac));
        draw();
    end

    function update_specular(source,callbackdata)
        specular_i = round(get(source, 'Value'));
        specular_indices(:,:,:) = specular_i;
        set(specular_display, 'String', num2str(intensity_values(specular_i)));
        draw();
    end

    function change_brdf(source,callbackdata)
        if get(source, 'Value') == 0
            set(source, 'Value', 1);
        end
        display('changing brdf to...');
        result = get(source, 'String')
        if strcmp(result, 'Phong')
            set(torrance_brdf_box, 'Value', 0);
            current_exp_list = specular_exponents;
        else
            set(phong_brdf_box, 'Value', 0);
            current_exp_list = sigmas;
        end
        brdf_model = result;
        draw();
            
    end

    function change_colour(source,callbackdata)
        new_col = uisetcolor([intensity_values(diffuser_i) intensity_values(diffuseg_i) intensity_values(diffuseb_i)]);
        
        new_r = round(new_col(1) * 10) / 10;
        new_g = round(new_col(2) * 10) / 10;
        new_b = round(new_col(3) * 10) / 10;
        
        diffuser_indices(:,:,:) = find(intensity_values == new_r);
        diffuseg_indices(:,:,:) = find(intensity_values == new_g);
        diffuseb_indices(:,:,:) = find(intensity_values == new_b);
        draw();
    end

    function draw_diffuse(source,callbackdata)
        
        new_col = uisetcolor([intensity_values(diffuser_i) intensity_values(diffuseg_i) intensity_values(diffuseb_i)]);
        new_r = round(new_col(1) * 10) / 10;
        new_g = round(new_col(2) * 10) / 10;
        new_b = round(new_col(3) * 10) / 10;

        new_diffuser_i = find(intensity_values == new_r);
        new_diffuseg_i = find(intensity_values == new_g);
        new_diffuseb_i = find(intensity_values == new_b);

        draw_new_diffuse();

    end

    function draw_new_diffuse()
    	subplot(2, 2, 1);
        h = imfreehand('Closed', false);
        points = int64(h.getPosition());
        numpoints = size(points, 1);
        xpoints = points(:,1);
        ypoints = points(:,2);
        
        % gaussians(i) will hold the intensity of the brush at distance
        % distance_values(i) from the center of the brush
        distance_values = 0:radius;
        for i = 1:(radius + 1)
            gaussians(i) = exp(-(distance_values(i)^2) / (2*(sigma^2))); % / (sigma*sqrt(2*pi));
        end
        distance_values = distance_values .^ 2; % since we are computing distance squared, for searching
        distance_values = int64(distance_values);

        % Colour all pixels with the radius of the selected points
        for x = max(min(xpoints) - radius, 1) : min(max(xpoints) + radius, width)
            for y = max(min(ypoints) - radius, 1) : min(max(ypoints) + radius, height)
                distances = (x - xpoints).^2 + (y - ypoints).^2;
                if min(distances) < radius^2
                    % (x,y) is within the radius of one of the points
                    % paint it
                    %diffuser_indices(y, x) = new_diffuser_i;
                    %diffuseg_indices(y, x) = new_diffuseg_i;
                    %diffuseb_indices(y, x) = new_diffuseb_i;
                    %x
                    %y
                    [tmp index] = min(abs(distance_values-round(min(distances))));
                    %index
                    intensity = gaussians(index);
                    diffuser_value = (1-intensity)*intensity_values(diffuser_indices(y, x)) + ...
                        intensity*new_r;
                    diffuser_value = round(diffuser_value * (1/intensity_step)) / (1/intensity_step);
                    diffuser_indices(y, x) = find(intensity_values == diffuser_value);
                    
                    diffuseg_value = (1-intensity)*intensity_values(diffuseg_indices(y, x)) + ...
                        intensity*new_g;
                    diffuseg_value = round(diffuseg_value * (1/intensity_step)) / (1/intensity_step);
                    diffuseg_indices(y, x) = find(intensity_values == diffuseg_value);
                    
                    diffuseb_value = (1-intensity)*intensity_values(diffuseb_indices(y, x)) + ...
                        intensity*new_b;
                    diffuseb_value = round(diffuseb_value * (1/intensity_step)) / (1/intensity_step);
                    diffuseb_indices(y, x) = find(intensity_values == diffuseb_value);
                    
                    %display('distance = ');
                    %min(distances)
                end
            end
        end

        draw();
    end  

    function draw_specular_intensity(source, callback, increase)
        % increase = true to increase intensity, false to decrease
        subplot(2, 2, 1);
        h = imfreehand('Closed', false);
        points = int64(h.getPosition());
        numpoints = size(points, 1);
        xpoints = points(:,1);
        ypoints = points(:,2);
        
        % gaussians(i) will hold the intensity of the brush at distance
        % distance_values(i) from the center of the brush
        distance_values = 0:radius;
        for i = 1:(radius + 1)
            gaussians(i) = exp(-(distance_values(i)^2) / (2*(sigma^2))); % / (sigma*sqrt(2*pi));
        end
        distance_values = distance_values .^ 2; % since we are computing distance squared, for searching
        distance_values = int64(distance_values);

        % Colour all pixels with the radius of the selected points
        for x = max(min(xpoints) - radius, 1) : min(max(xpoints) + radius, width)
            for y = max(min(ypoints) - radius, 1) : min(max(ypoints) + radius, height)
                distances = (x - xpoints).^2 + (y - ypoints).^2;
                if min(distances) < radius^2
                    % (x,y) is within the radius of one of the points
                    % paint it
                    %x
                    %y
                    [tmp index] = min(abs(distance_values-round(min(distances))));
                    %index
                    current_intensity = intensity_values(specular_indices(y, x));
                    intensity = gaussians(index);
                    if increase && current_intensity <= 0.7
                        new_spec_value = (1-intensity)*current_intensity + intensity*(current_intensity + 0.3);
                    elseif ~increase && current_intensity >= 0.3
                        new_spec_value = (1-intensity)*current_intensity + intensity*(current_intensity - 0.3);
                    end
                    new_spec_value = round(new_spec_value * (1/intensity_step)) / (1/intensity_step);
                    specular_indices(y, x) = find(intensity_values == new_spec_value);

                end
            end
        end
        draw();
    end

    function draw_specular_intensity_old(source, callback, increase)
        % increase = true to increase intensity, false to decrease
        
        % should allow for spatial variation here too
        % BRDF shop method:
        % press down mouse, every time you move the mouse it increases
        % globally by one index
        
        % if increase: (just do opposite for decrease)
        % new spec intensity index = current intensity index + 1
        % WindowButtonDownFcn -> in this function, set:
        %     WindowButtonMotionFcn -> new spec intensity index = current intensity index + 1
        % and WindowButtonUpFcn -> in this function, remove WindowButtonMotionFcn
        
        global counter;
        counter = 0;
        
        subplot(2, 2, 1);
        set(gcf, 'Pointer', 'crosshair');
        set(gcf, 'WindowButtonDownFcn', {@specularMouseDown, increase});
        set(gcf, 'WindowButtonUpFcn', @drawingMouseUp);
        
    end

    function draw_specular_exp(source, callbackdata) 
        % Click to start, drag mouse to desired spread
        subplot(2, 2, 1);
        set(gcf, 'Pointer', 'crosshair');
        set(gcf, 'WindowButtonDownFcn', @specularExpMouseDown);
        set(gcf, 'WindowButtonUpFcn', @drawingMouseUp);
    end  

    function draw_sharpen(source, callbackdata)
        
        blur_sharpen_brush(false);
    end

    function draw_blur(source, callbackdata)
        
        blur_sharpen_brush(true);
    end

    function blur_sharpen_brush(blur)
        % blur = true => increase blur
        % blur = false => decrease blur
        subplot(2, 2, 1);
        h = imfreehand('Closed', false);
        points = int64(h.getPosition());
        numpoints = size(points, 1);
        xpoints = points(:,1);
        ypoints = points(:,2);
        
        for i = 1:numpoints
            center_x = xpoints(i);
            center_y = ypoints(i);
        
            % blur the area surrounding center with the radius defined by
            % global parameter radius
            for x = (center_x - radius) : (center_x + radius)
                for y = (center_y - radius) : (center_y + radius)
                    if ((x - center_x)^2 + (y - center_y)^2) <= radius^2
                        %display('specular');
                        %x
                        %y
                        %specular_exp_indices(y, x) = 20;
                        if blur
                            if strcmp(brdf_model, 'Phong') && (specular_exp_indices(y, x) > 2)
                                specular_exp_indices(y, x) = specular_exp_indices(y, x) - 1;
                            elseif strcmp(brdf_model, 'Torrance-Sparrow') && (specular_exp_indices(y, x) < num_exponents)
                                specular_exp_indices(y, x) = specular_exp_indices(y, x) + 1;
                            end
                        else
                            if strcmp(brdf_model, 'Phong') && (specular_exp_indices(y, x) < num_exponents)
                                specular_exp_indices(y, x) = specular_exp_indices(y, x) + 1;
                            elseif strcmp(brdf_model, 'Torrance-Sparrow') && (specular_exp_indices(y, x) > 2)
                                specular_exp_indices(y, x) = specular_exp_indices(y, x) - 1;
                            end
                        end
                    end
                end
            end
        end  
        draw();
        
    end  

    function save_image(source, callbackdata)
        imwrite(env_display_img, strcat('environment_image_', num2str(written_image_count), '.bmp'));
        written_image_count = written_image_count + 1;
    end

    %%%%%%%%%%%%%%%%%%%%%%%% CALLBACK FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%

    function diffuseKeyPress(hObject, event)

        if (strcmp(event.Key, 'return'))
            draw_new_diffuse();
        end
    end

    function specularMouseDown(hObject, event, increase)
        subplot(2, 2, 1);
        set(gcf, 'WindowButtonMotionFcn', {@specularMouseMotion, increase});
        %display('drawing...');
        
    end

    function drawingMouseUp(hObject, event)
        subplot(2, 2, 1);
        global mouseUp;
        mouseUp = true;
        set(gcf, 'WindowButtonMotionFcn', '');
        set(gcf, 'WindowButtonDownFcn', '');
        %display('done drawing');
        set(gcf, 'Pointer', 'arrow');
    end

    function specularMouseMotion(hObject, event, increase)
        global counter;
        counter = counter + 1;
        if mod(counter, 5) == 0
            % new spec intensity index = current intensity index + 1 (or -1 for
            % decrease)
            if increase && specular_i < num_intensities
                specular_i = specular_i + 1;
                draw();
            elseif ~increase && specular_i > 1
                specular_i = specular_i - 1;
                draw();
            end
        end
        
    end

    function specularExpMouseDown(hObject, event)
        subplot(2, 2, 1);
        global previous_pt;
        if strcmp(get(hObject, 'SelectionType'),'normal')
            previous_pt = get(gcf, 'CurrentPoint');
            set(gcf, 'WindowButtonMotionFcn', @specularExpMouseMotion);
        end  
    end

    function specularExpMouseMotion(hObject, event)
        % Move up to increase spread, down to decrease
        % For Phong, increasing exponent DECREASES spread
        % For Torrance, increasing exponent (sigma) INCREASES spread
        subplot(2, 2, 1);
        global previous_pt;
        current_pt = get(gcf, 'CurrentPoint');
        if (current_pt(2) > previous_pt(2))
            if strcmp(brdf_model, 'Phong') && (specular_exp_i > 1)
                specular_exp_i = specular_exp_i - 1;
            elseif strcmp(brdf_model, 'Torrance-Sparrow') && (specular_exp_i < num_exponents)
                specular_exp_i = specular_exp_i + 1;
            else
                return;
            end
            
        elseif (current_pt(2) < previous_pt(2))
            if strcmp(brdf_model, 'Phong') && (specular_exp_i < num_exponents)
                specular_exp_i = specular_exp_i + 1;
            elseif strcmp(brdf_model, 'Torrance-Sparrow') && (specular_exp_i > 1)
                specular_exp_i = specular_exp_i - 1;
            else
                return;
            end
        else
            return;
        end
            
        draw();
        previous_pt = current_pt;
    end


end
    

