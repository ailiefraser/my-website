Interactive Piano
By David Liu and Ailie Fraser

To run this program on a Mac, cd into the “bin” directory and run piano_mac.
(Don’t just double-click on it in the Finder. You need to be in the bin directory
for it to run properly.)

Open /Applications/Utilities/Terminal, and type the following
cd <location of piano_mac folder>/piano_mac/bin
./piano_mac

Let me know if you run into any problems at ailie.fraser@utoronto.ca.
Enjoy!

