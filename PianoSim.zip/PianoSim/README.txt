To run the program, simply double-click on start_me.bat, or run Release/PianoSim.exe.

Please let me know if something goes wrong at liudavid@cs.toronto.edu!